"""Serve this example locally with the WebVTT media type on every platform."""
import mimetypes
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

if __name__ == "__main__":
    mimetypes.add_type("text/vtt", ".vtt")
    handler = partial(SimpleHTTPRequestHandler, directory=str(Path(__file__).parent))
    with ThreadingHTTPServer(("127.0.0.1", 8000), handler) as server:
        print("Open http://127.0.0.1:8000 (Ctrl-C to stop)", flush=True)
        server.serve_forever()
