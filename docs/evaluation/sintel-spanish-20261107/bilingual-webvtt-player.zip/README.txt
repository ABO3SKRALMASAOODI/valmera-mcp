From this folder run: python3 serve.py
Open http://127.0.0.1:8000 in your browser. Choose English or Spanish in the subtitle menu.
