# AI video editing revision test

A silent motion graphic with a burned-in source clock, a first cut and a revised delivery. Use them to test whether an editor makes a requested two-second revision on existing footage.

## Task

Use the 25-second original. Keep seconds 3–7, 12–16 and 19–23, in order. Make a centered square crop at 30 fps with hard cuts. Then shorten the middle selection to 12–14. The closing shot now starts at output second 6. Its first frame shows source second 19. All source ranges include the start and exclude the end.

## Files

- `original-source.mp4` contains the 1280 × 720 source.
- `first-preview.mp4` is the 12-second 720 × 720 preview before the revision.
- `revised-final.mp4` is the delivered 1080 × 1080 file with ten program seconds and five seconds of branding.
- `frame_targets.json` maps each output frame to the original under each brief. The map covers program frames. A watermark can change decoded pixels.
- `evidence.json` records the public November 7 MCP run and hashes.
- `LICENSE.txt` reproduces the upstream repository license.

Made and published by Valmera with a synthetic source. No customer footage. The shot choices are supplied. This sample measures temporal selection and framing on one file. It provides no evidence about editorial taste, speech editing, or model rankings.

[Run the MP4 comparison](https://colab.research.google.com/github/ABO3SKRALMASAOODI/valmera-mcp/blob/main/docs/examples/video-edit-revision/check-revision.ipynb) · [Recorded editing procedure](https://github.com/ABO3SKRALMASAOODI/valmera-mcp/blob/main/docs/MCP-RECORDED-EDIT.md) · [Editing existing footage with Valmera](https://valmera.io/ai-video-editor)

## Run the checks from this download

Extract the archive. Open `check-revision.ipynb` in Jupyter from that folder, with Pillow, FFmpeg and ffprobe installed. Run all cells to see the two frames around the revised join and compare a custom export with either brief. The included notebook uses the bundled MP4s offline.

For the same timing check across two editors, run `python3 score.py` in the extracted folder with FFmpeg installed. `first-cut.mp4` and `shorter-cut.mp4` were exported by MakeMyClip Editor 0.4.2. `comparison.json` lists the local MCP calls, output dimensions, checksums and counts for both editors. The script compares the central square of each picture to accommodate different canvas shapes. All four exports matched their intended schedule more closely on all 120 disputed frames. The test measures shot timing on this clip.

[Compare the four exports and view the editing procedure](https://valmera.io/claude-video-editor#local-and-hosted).
