Replay handoff test

Install Python 3. In this folder, run:
  python3 remap_after_cuts.py recorded-source-chapters.txt recorded-removed-ranges.txt 00:12 > candidate-chapters.txt
  python3 retime_srt_after_cuts.py source-cues.srt --remove 6 8 > candidate-cues.srt
  python3 check_srt_revision.py candidate-cues.srt reviewed-cues.srt

The caption labels are teaching annotations for a silent sample.
Check the two videos at six seconds:
  Before: https://valmera.io/examples/agent-revision/first-preview.mp4
  After:  https://valmera.io/examples/agent-revision/revised-final.mp4

The source-media clock stays separate from the first edited timeline.
For this exercise, 6 to 8 seconds refers to the first edited program.
